package atividades2;

import java.util.Scanner;

class ativ_d {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
			int preco;
			
			System.out.println("digite o pre�o da gasolina");
			preco=sc.nextInt();
					
			System.out.println("o pre�o com acr�ssimo de 10% �: "+ preco*1.10);

	}

}
