package atividades2;

import java.util.Scanner;

class ativ_e {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
			int salario;
			
			System.out.println("digite o seu salario");
			salario=sc.nextInt();
					
			System.out.println("o sal�rio final de 10% �: "+ salario*1.04);

	}

}
